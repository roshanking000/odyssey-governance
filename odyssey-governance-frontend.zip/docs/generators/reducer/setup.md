### Reducer

src/store/rootSaga.ts
раскомментировать строку
// import { fork } from 'redux-saga/effects';