### Page

```bash
yarn run new
page
```

Создает страницу

<details>
  <summary>Структура добавляемых файлов</summary>

  ```bash
  my-project
  |-- src
  |   |-- pages
  |   |   |-- название страницы
  |   |        |-- index.tsx
  |   |   |-- index.ts
  ```
</details>