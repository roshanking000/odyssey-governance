export { default as DioneProtocolIcon } from './dioneProtocolIcon.svg';
export { default as checkMark } from './checkMark.svg';
export { default as ClockIcon } from './clock.svg';
export { default as PercentIcon } from './percent.svg';
export { default as StopIcon } from './stop.svg';
export { default as LoadingIcon } from './loading.svg';
export { default as PrimaryArrow } from './primaryArrow.svg';
export { default as Avatar } from './avatar.svg';
export { default as ArrowLink } from './arrow-link.svg';
export { default as ArrowIcon } from './arrow.svg';
export { default as ArrowBottomIcon } from './arrowBottom.svg';
export { default as GlassIcon } from './glass.svg';
export { default as SunIcon } from './sun.svg';

export { default as Ellipse1 } from './ellipse1.svg';
export { default as Ellipse2 } from './ellipse2.svg';
export { default as Ellipse3 } from './ellipse3.svg';
export { default as Ellipse4 } from './ellipse4.svg';
