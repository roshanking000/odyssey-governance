import { Network, networkChains } from 'appConstants';

export const getNetworkName = (chainId?: string): Network | null => {
  const target = (Object.keys(networkChains) as Network[]).find((key) =>
    networkChains[key] === chainId);
  return target || null;
};

export default getNetworkName;
