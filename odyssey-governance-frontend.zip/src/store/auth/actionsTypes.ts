export enum AuthActionTypes {
  SetState = 'AUTH.SET_STATE',
  SetStatus = 'AUTH.SET_STATUS',
  GetData = 'AUTH.GET_DATA',
}
