import { State } from 'types/store';

export const authSelectors = {
  getProp: <PropKey extends keyof State['auth']>(propKey: PropKey) => (
    state: State,
  ) => state.auth[propKey],
  getStatus: <T extends keyof State['auth']['ui']>(propKey: T) => (state: State) => state.auth.ui[propKey],
};
