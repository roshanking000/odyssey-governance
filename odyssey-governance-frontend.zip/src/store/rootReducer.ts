import proposal from './proposal';
import auth from './auth';
import metamask from './metamask';

export default {
  proposal,
  auth,
  metamask,
};
