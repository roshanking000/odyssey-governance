export enum RequestStatus {
  INIT = 'INIT',
  REQUEST = 'REQUEST',
  SUCCESS = 'SUCCESS',
  RESET = 'RESET',
  ERROR = 'ERROR',
}
